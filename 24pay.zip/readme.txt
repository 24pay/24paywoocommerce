== Description ==
24pay payment gateway for WooCommerce

Current version 1.1.0

= Released  = [02.11.2022]
= ver 1.0.1 = [08.10.2021]
= ver 1.0.0 = [21.11.2018]

= Last Time Tested [WC 7.6.1 WP 6.2.0]
= Recently Tested [WC 7.0.1 WP 6.1.0]
= Recently Tested [WC 6.1.1 WP 5.8.1]
= Recently Tested [WC 5.7.1 WP 5.8.1]
= Recently Tested [WC 5.6.0 WP 5.8.0]
= Recently Tested [WC 5.2.2 WP 5.7.1]
= Recently Tested [WC 4.8.0 WP 5.6.2]
= Recently Tested [WC 4.7.1 WP 5.3.3]
= Recently Tested [WC 4.5.1 WP 5.3.3]
= Recently Tested [WC 4.0.1 WP 5.3.2]
= Recently Tested [WC 3.8.1 WP 5.3.0]
= Recently Tested [WC 3.7.0 WP 5.2.3]
= Recently Tested [WC 3.6.5 WP 5.2.3]
= Recently Tested [WC 3.6.4 WP 5.2.1]
= Recently Tested [WC 3.6.2 WP 5.1.1]
= Recently Tested [WC 3.5.3 WP 5.0.2]


Spoločnosť 24-pay poskytuje moduly pre jednoduchú implementáciu komunikácie s platobnou bránou. Moduly boli testované na čistej inštalácií daného CMS systému. Spoločnosť si vyhradzuje právo odmietnuť úpravy modulov spôsobené kolíziami s dodatočne inštalovanými modulmi. Špecifické problémy (notifikovanie klientov, generovanie faktúr a pod) konzultujte s vaším developerom, ktorý môže modul ďalej upravovať podľa vašich predstáv.
